package com.hcl.busbooking.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.busbooking.model.BusRoute;

public interface BusRouteRepository extends JpaRepository<BusRoute, Integer>{
	

}
