package com.hcl.busbooking.model;

public enum Gender {
	 MALE,
	    FEMALE
}
